//line 1
public class MAIN {
//line 3
	public static void main(String[] args) {
		System.out.println("Hello World"); //line 5
	}
//line 7
}
//line 9
