package nl.berg.packt.pmdrule;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        String PASSWORD="secret";
     }
}
