package nl.berg.packt.findbugs_all.candles;

public class FindbugsFBCandle {
	
	public String FBexample(){
		String answer="This is the answer";
		return answer;
	}
}
