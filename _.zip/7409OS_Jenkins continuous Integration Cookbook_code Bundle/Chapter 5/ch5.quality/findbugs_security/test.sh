mvn clean package findbugs:findbugs
