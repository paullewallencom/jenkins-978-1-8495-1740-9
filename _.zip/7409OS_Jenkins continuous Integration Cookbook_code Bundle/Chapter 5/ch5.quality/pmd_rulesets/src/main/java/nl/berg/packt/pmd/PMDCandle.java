package nl.berg.packt.pmd;
import java.util.Date;

public class PMDCandle {
	private String MyIP = "123.123.123.123";
	
	public void dontDontDoThisInYoourCode(){	
		System.out.println("Logging Framework please");
		try {
			int x =5;	
		}catch(Exception e){}
		String myString=null;
		if (myString.contentEquals("NPE here"));		
	}

}
