#!/usr/bin/perl
print "guest,all";
exit(0);
